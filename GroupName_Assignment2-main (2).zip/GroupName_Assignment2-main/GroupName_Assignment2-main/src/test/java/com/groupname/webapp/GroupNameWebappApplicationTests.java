package com.groupname.webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupNameWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
