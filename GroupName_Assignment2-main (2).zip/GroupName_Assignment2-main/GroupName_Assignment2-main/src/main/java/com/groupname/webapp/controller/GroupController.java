package com.groupname.webapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.groupname.webapp.model.Member;
import java.util.Arrays;
import java.util.List;

@Controller
public class GroupController {

    @GetMapping("/group")
    public String showGroup(Model model) {
        List<Member> members = Arrays.asList(
            new Member("Jaimin", "DB Analyst", "member1.jpg"),
            new Member("Seungyeol", "DB Analyst", "IMG_4743.jpeg") ,// New member added
            new Member("Huy", "Frontend Developer", "huyhoang.jpg") // New member added
           
        );

        model.addAttribute("members", members);
        return "group";
    }
}
